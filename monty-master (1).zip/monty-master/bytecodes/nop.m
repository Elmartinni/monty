nop
push 1
nop
push 2
nop
push 3
nop
pall
nop
pall
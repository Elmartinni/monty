push 1
push 2
push 20
push 5
mul
pall
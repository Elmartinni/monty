push 1
pint
push 2
pint
push 3
pint
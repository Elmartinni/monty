#hello world
#hahahaha
#cisfun
#montyisfun
push 10
push 2
push 8
push 5
pall
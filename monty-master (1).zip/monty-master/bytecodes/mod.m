push 1
push 2
push 90
push 5
mod
pall